#include "leaderboardwindow.h"
#include "ui_leaderboardwindow.h"


LeaderboardWindow::LeaderboardWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::LeaderboardWindow)
{
    ui->setupUi(this);
}

LeaderboardWindow::~LeaderboardWindow()
{
    delete ui;
}

void LeaderboardWindow::setLeaderboard(const QMap<QString, int>& leaderboard)
{
    QString leaderboardText;
    for (const auto& entry : leaderboard) {
        leaderboardText += entry.first + " : " + QString::number(entry.second) + "\n";
    }
    ui->textEdit->setText(leaderboardText);
}

