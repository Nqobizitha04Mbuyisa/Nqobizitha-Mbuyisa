
#ifndef LEADERBOARDWINDOW_H
#define LEADERBOARDWINDOW_H

#include <QMainWindow>
#include <QMap>
#include <QString>

namespace Ui {
class LeaderboardWindow;
}

class LeaderboardWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit LeaderboardWindow(QWidget *parent = nullptr);
    ~LeaderboardWindow();


     void setLeaderboard(const QMap<QString, int>& leaderboard);

private:
    Ui::LeaderboardWindow *ui;

};

#endif // LEADERBOARDWINDOW_H

