#include "levelselect.h"
#include "ui_levelselect.h"

#include "quiz.h"
#include "quizlvl2.h"
#include "quizlvl3.h"

#include <QMessageBox>

#include "startminigame.h"

#include "myfile.h"

#include "maindescription.h"
#include "ui_maindescription.h"

levelSelect::levelSelect(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::levelSelect)
{
    ui->setupUi(this);

}

levelSelect::~levelSelect()
{
    delete ui;
}

void levelSelect::on_level1Button_clicked()
{
    // QMessageBox msgBox;

    // msgBox.setWindowTitle("LEVEL 1 Upcoming");
    // msgBox.setText("Ready for Level 1?");
    // QPushButton *yesButton = msgBox.addButton(tr("Yes"), QMessageBox::AcceptRole);

    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this,"Level 1 Upcoming!","Ready for Level 1?",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes){

    //msgBox.exec();

    //if (msgBox.clickedButton() == yesButton) {
        Quiz *myQuiz =new Quiz();
        myQuiz->displayQuestion(myQuiz->currentQuestionIndex);
        myQuiz ->show();
        this->hide();
    }
    //this->hide();
}


void levelSelect::on_level2Button_clicked()
{
    // QMessageBox msgBox;

    // msgBox.setWindowTitle("LEVEL 2 Upcoming");
    // msgBox.setText("Ready for Level 2?");
    // QPushButton *yesButton = msgBox.addButton(tr("Yes"), QMessageBox::AcceptRole);


    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this,"Level 2 Upcoming!","Ready for Level 2?",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes){

    //msgBox.exec();

    //if (msgBox.clickedButton() == yesButton) {
        quizLvl2 *quiz2 = new quizLvl2;
        quiz2->displayQuestion(quiz2->currentQuestionIndex);
        quiz2->show();
        this->hide();
    }
    //quizLvl2 *quiz2 =new quizLvl2();
    //quiz2->displayQuestion(QRandomGenerator::global()->bounded(quiz2->questions.size()));
    //quiz2 ->showMaximized();
    //this->hide();
}


void levelSelect::on_level3Button_clicked()
{
   // QMessageBox msgBox;

    //msgBox.setWindowTitle("LEVEL 3 Upcoming");
    //msgBox.setText("Ready for Level 3?");
    //QPushButton *yesButton = msgBox.addButton(tr("Yes"), QMessageBox::AcceptRole);

    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this,"Level 3 Upcoming!","Ready for Level 3?",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes){

    //msgBox.exec();

    //if (msgBox.clickedButton() == yesButton) {
        quizLvl3 *quiz3 =new quizLvl3();
        quiz3->displayQuestion(quiz3->currentQuestionIndex);
        quiz3 ->show();
        this->hide();
    }
    //this->hide();
}


void levelSelect::on_minigamebutton_clicked()
{
    startminigame *startDes = new startminigame();
    startDes->show();
    this->hide();
}

void levelSelect::resizeEvent(QResizeEvent *event)
{
    QWidget::resizeEvent(event);
    myFile file;
    file.setBackgroundImage(this, ":/images/pexels-ekamelev-920157.jpg");
}


void levelSelect::on_pushButton_clicked()//LOGOUT BUTTON
{
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Exit", "Are you sure you want to Log out?", QMessageBox::Yes | QMessageBox::No);
    if (reply == QMessageBox::Yes) {
        this ->hide();
        MainWindow *wind = new MainWindow();
        //wind ->showMaximized();
        wind->show();
    }
}

