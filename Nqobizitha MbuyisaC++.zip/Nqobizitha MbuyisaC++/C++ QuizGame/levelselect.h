#ifndef LEVELSELECT_H
#define LEVELSELECT_H
#include "myfile.h"

#include <QDialog>

namespace Ui {
class levelSelect;
}

class levelSelect : public QDialog
{
    Q_OBJECT

public:
    explicit levelSelect(QWidget *parent = nullptr);
    ~levelSelect();

private slots:
    void on_level1Button_clicked();

    void on_level2Button_clicked();

    void on_level3Button_clicked();

    void on_minigamebutton_clicked();

    void on_pushButton_clicked();

private:
    Ui::levelSelect *ui;
    void resizeEvent(QResizeEvent *event);
};

#endif // LEVELSELECT_H
