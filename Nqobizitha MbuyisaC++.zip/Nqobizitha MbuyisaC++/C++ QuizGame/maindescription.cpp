#include "maindescription.h"
#include "ui_maindescription.h"
#include "myfile.h"
#include "quiz.h"
#include "levelselect.h"

#include "QRandomGenerator"

#include <QMessageBox>
MainDescription::MainDescription(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainDescription)
{
    ui->setupUi(this);
}
MainDescription::~MainDescription()
{
    delete ui;
}
void MainDescription::on_pushButton_clicked()
{
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Exit", "Are you sure you want to Log out?", QMessageBox::Yes | QMessageBox::No);
    if (reply == QMessageBox::Yes) {
        this ->hide();
        MainWindow *wind = new MainWindow();
        //wind ->showMaximized();
        wind->show();
    }
}
/*void MainDescription::resizeEvent(QResizeEvent *event)
{
    QWidget::resizeEvent(event);
    myFile::setBackgroundImage(this,":/images/pexels-ekamelev-920157.jpg");
}*/
void MainDescription::resizeEvent(QResizeEvent *event)
{
    QWidget::resizeEvent(event);
    myFile file;
    file.setBackgroundImage(this, ":/images/pexels-ekamelev-920157.jpg");
}

void MainDescription::on_startAttemp_clicked()
{

    levelSelect *levelNum = new levelSelect();
    levelNum->show();
    //Quiz *myQuiz =new Quiz();
    //myQuiz->displayQuestion(QRandomGenerator::global()->bounded(myQuiz->questions.size()));
    //myQuiz ->showMaximized();
    this ->hide();
}

