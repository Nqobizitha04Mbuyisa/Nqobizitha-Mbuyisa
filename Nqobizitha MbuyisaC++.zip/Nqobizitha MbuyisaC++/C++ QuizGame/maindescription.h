#ifndef MAINDESCRIPTION_H
#define MAINDESCRIPTION_H

#include <QMainWindow>
#include "mainwindow.h"
#include "quiz.h"


namespace Ui {
class MainDescription;
}

class MainDescription : public QMainWindow
{
    Q_OBJECT

public:

    explicit MainDescription(QWidget *parent = nullptr);
    ~MainDescription();

private slots:
    void on_pushButton_clicked();

    //void on_startAttempt_clicked();

    void on_startAttemp_clicked();

private:
    Ui::MainDescription *ui;
     void resizeEvent(QResizeEvent *event);
};

#endif // MAINDESCRIPTION_H
