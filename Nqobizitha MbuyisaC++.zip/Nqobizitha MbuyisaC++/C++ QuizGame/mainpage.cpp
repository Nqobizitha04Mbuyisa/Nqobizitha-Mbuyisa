#include "mainpage.h"
#include "ui_mainpage.h"

#include <QPixmap>
#include "myfile.h"


#include <QMessageBox>

MainPage::MainPage(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainPage)
{
    ui->setupUi(this);

}

MainPage::~MainPage()
{
    delete ui;
}

void MainPage::on_pushButton_clicked()
{

    this->hide();
    MainDescription *des = new MainDescription();
    //des -> showMaximized();
    des->show();
}

/*void MainPage::resizeEvent(QResizeEvent *event1)
{
    QWidget::resizeEvent(event1);
    myFile::setBackgroundImage(this,":/images/pexels-ekamelev-920157.jpg");

}*/
void MainPage::resizeEvent(QResizeEvent *event)
{
    QWidget::resizeEvent(event);
    myFile file;
    file.setBackgroundImage(this, ":/images/pexels-ekamelev-920157.jpg");
}
