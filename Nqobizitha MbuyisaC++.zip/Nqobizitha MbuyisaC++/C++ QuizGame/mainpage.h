#ifndef MAINPAGE_H
#define MAINPAGE_H

#include <QMainWindow>


#include "myfile.h"
#include "maindescription.h"

namespace Ui {
class MainPage;
}

class MainPage : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainPage(QWidget *parent = nullptr);
    ~MainPage();

private slots:
    void on_pushButton_clicked();

private:
    Ui::MainPage *ui;
    void resizeEvent(QResizeEvent *event);
};

#endif // MAINPAGE_H
