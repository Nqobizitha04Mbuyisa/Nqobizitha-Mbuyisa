
#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QString>
#include <QMessageBox>
#include <QFile>
#include <QTextStream>
#include <QThread>
//#include <QTime>
#include <QTimer>


MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);

    //setWindowFlag(Qt::FramelessWindowHint);
    ui -> progressBar->setMinimum(1);
    ui -> progressBar->setMaximum(100);
    ui -> progressBar->setRange(1,100);

}
MainWindow::~MainWindow() {
    delete ui;
}


bool MainWindow::userExists(const QString& username, const QString& password) {
    QFile file("users.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return false;

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList parts = line.split(":");
        //if (parts.size() == 2 && parts[0] == username && parts[1] == password) {
        if (parts.size() == 2 && parts[0].trimmed() == username && parts[1].trimmed() == password) {
            file.close();
            return true;
        }
    }
    file.close();
    return false;
}

/*void MainWindow::resizeEvent(QResizeEvent *event)
{
    QWidget::resizeEvent(event);
    myFile::setBackgroundImage(this,":/images/pexels-ekamelev-920157.jpg");


}*/
void MainWindow::resizeEvent(QResizeEvent *event)
{
    QWidget::resizeEvent(event);
    myFile file;
    file.setBackgroundImage(this, ":/images/pexels-ekamelev-920157.jpg");
}
void MainWindow::on_pushButton_cancel_clicked() {
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Exit", "Are you sure you want to exit?", QMessageBox::Yes | QMessageBox::No);
    if (reply == QMessageBox::Yes) {
        QApplication::quit();
    }
}
void MainWindow::on_pushButton_login_clicked() {
    QString userName = ui->username->text().trimmed();
    QString password = ui->password->text().trimmed();

    if (userExists(userName, password)) {
        QTimer *timer = new QTimer(this);
        connect(timer, &QTimer::timeout, this, [=]() {
            static int value = ui->progressBar->minimum();
            if (value <= ui->progressBar->maximum()) {
                ui->progressBar->setValue(value);
                ui->label_loging->setText(QString::number(value) + " % ");
                value++;
            } else {
                timer->stop();

                this->hide();
                // Open your main page after successful login
                MainPage *mainpage = new MainPage();
                //mainpage->showMaximized();
                mainpage->show();
                delete timer; // Clean up the timer
            }
        });
        timer->start(30); // Update progress bar every 30 milliseconds
    } else {
        QMessageBox::warning(this, "Login", "Username or password invalid, please register to continue");
    }
}


void MainWindow::on_pushButton_register_clicked() {
    QString userName = ui->username->text().trimmed();
    QString password = ui->password->text().trimmed();

    if (userName.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "Registration", "Enter your username and password");
        return;
    }

    if (userExists(userName, password)) {
        QMessageBox::warning(this, "Registration", "Username already exists, Click Login");
        return;
    }

    QFile file("users.txt");
    if (!file.open(QIODevice::Append | QIODevice::Text)) {
        QMessageBox::critical(this, "Error", "Could not save user to file!");
        return;
    }

    QTextStream out(&file);
    out <<userName << " : " << password << "\n";
    file.close();

    QMessageBox::information(this, "Registration", "Registration Successful");
}
