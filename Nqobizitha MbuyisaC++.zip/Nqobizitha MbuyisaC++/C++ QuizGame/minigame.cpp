#include "minigame.h"
#include "ui_minigame.h"
#include "myfile.h"
#include "levelselect.h"

#include <QMovie>
#include <QWidget>
#include <QDebug>
#include <QString>
#include <QTime>
#include <QMessageBox>
#include <QGridLayout>
#include <QLabel>
#include <QLineEdit>
#include <QRandomGenerator>
#include <QChar>
#include <QPushButton>
#include <QSet> // Include QSet for occupiedCells and
#include "minigame.h"

minigame::minigame(QWidget *parent)//constructor
    : QMainWindow(parent)
    , ui(new Ui::minigame)
    , times(new QTimer(this)) // Initialize timer

{
    //constructor of file
    ui->setupUi(this);
    QMovie *movie = new QMovie(":/images/celebration_GIF.gif");
    ui->gifLabel->setMovie(movie);
    movie->start();
    ui->gifLabel->setVisible(false);

    //ui->leaderBoard->setVisible(false);

    //call the function to add words
    addWordsToFind();

    //call the function to populate the word search
    populateWordSearch();

    //timer declaration
    connect(times,SIGNAL(timeout()),this,SLOT(startTimer()));
    times->start(1000);
}

minigame::~minigame()
{
    delete ui;
}

void minigame::resizeEvent(QResizeEvent *event)
{
    QWidget::resizeEvent(event);
    myFile file;
    file.setBackgroundImage(this,":/images/biology.jpg");
}

/*void MiniGame::closeEvent(QCloseEvent *)
{
    QApplication::quit();
}*/

//set the timer for the wordsearch... when timer stops shows message that time is up and player will view leaderboard
void minigame::startTimer()
{
    static int seconds=0;
    seconds++;

    // Create a QTime object with the current time
    QTime time = QTime(0,10,0).addSecs(-seconds);

    // Format the time as "HH : MM : SS"
    //QString
    time_text = time.toString("hh : mm : ss");

    ui->timeTextLabel->setText(time_text);

    if(time_text=="00 : 00 : 00")
    {
        //displays message box when time is up
        QMessageBox::warning(this,"Time","Time is up!!! You will now be viewing the leader board.");
        //this->close();
        //ui->leaderBoard->setVisible(true);
        //QApplication::quit(); // Ensure the application exits

    }
}

void minigame::populateWordSearch()
{
    //QString word;
    int gridSize = 15;
    //int wordLength,startX,startY;

    for (int i = 0; i<gridSize ; i++)
    {
        for (int j = 0; j<gridSize; j++)
        {
            // Generate a random integer between 0 and 25
            int randomIndex = QRandomGenerator::global()->bounded(26);
            // Convert the integer to a character, representing a letter from 'a' to 'z'
            QChar randomLetter = QChar('A' + randomIndex);
            //letterWord = QChar(letterWord);

            QPushButton *letter = new QPushButton(this);
            letter->setText(randomLetter);
            letter->setStyleSheet("color:rgb(0, 0, 0);background-color:rgb(255,255,255)");
            ui->gridLayout->setSpacing(0);
            ui->gridLayout->addWidget(letter, i, j);

            connect(letter, &QPushButton::pressed, this, &minigame::changeButtonColor);
        }
    }

    for (const QString &word : addWordsVector)
    {
        /*int row = QRandomGenerator::global()->bounded(gridSize);
        int column = QRandomGenerator::global()->bounded(gridSize);
        int directionX = QRandomGenerator::global()->bounded(-1, 2); // -1, 0, or 1
        int directionY = QRandomGenerator::global()->bounded(-1, 2);*/

        //qDebug()<<"For Loop:"<<"Row:_"<<row<<"Column:_"<<column<<"Direction X:_"<<directionX<<"Direction Y:_"<<directionY;
        bool wordPlaced = false;
        while (!wordPlaced)
        {
            int row = QRandomGenerator::global()->bounded(gridSize);
            int column = QRandomGenerator::global()->bounded(gridSize);
            int directionX = QRandomGenerator::global()->bounded(-1, 2); // -1, 0, or 1
            int directionY = QRandomGenerator::global()->bounded(-1, 2);

            //qDebug()<<"while Loop:"<<"Row:_"<<row<<"Column:_"<<column<<"Direction X:_"<<directionX<<"Direction Y:_"<<directionY;

            if (isWordPlacementPossible(word, row, column, directionX, directionY))
            {
                placeWord(word, row, column, directionX, directionY);
                wordPlaced = true;
            }
            /*else
            {
                row = QRandomGenerator::global()->bounded(gridSize);
                column = QRandomGenerator::global()->bounded(gridSize);
                directionX = QRandomGenerator::global()->bounded(-1, 2);
                directionY = QRandomGenerator::global()->bounded(-1, 2);
                //qDebug()<<"ROW-"<<row<<"Column_"<<column<<"Direction_X-"<<directionX<<"Direction_Y-"<<directionY;
            }*/
        }
    }
}

bool minigame::isWordPlacementPossible(const QString &word, int row, int column, int directionX, int directionY)
{
    int gridSize = 15;
    int wordLength = word.length();
    if (row + directionX * (wordLength - 1) >= gridSize ||
        column + directionY * (wordLength - 1) >= gridSize ||
        row + directionX * (wordLength - 1) < 0 ||
        column + directionY * (wordLength - 1) < 0 ||
        (directionX==0 && directionY==0))
    {
        return false;
    }
    for (int i = 0; i < wordLength; ++i)
    {
        int x = row + i * directionX;
        int y = column + i * directionY;
        //qDebug()<<"For Loop X_"<<x<<"Y_"<<y;
        if (occupiedCells.contains(QPoint(x, y)))
        {
            //qDebug()<<occupiedCells.contains(QPoint(x, y));
            return false;
        }
    }
    return true;
}

void minigame::placeWord(const QString &word, int row, int column, int directionX, int directionY)
{
    int wordLength = word.length();
    for (int i = 0; i < wordLength; ++i)
    {
        int x = row + i * directionX;
        int y = column + i * directionY;

        // Check if the cell is already occupied
        if (occupiedCells.contains(QPoint(x, y)))
        {
            // Skip placing the word if there is overlap
            return;
        }

        QPushButton *letter = qobject_cast<QPushButton *>(ui->gridLayout->itemAtPosition(x, y)->widget());
        letter->setText(word[i]);

        //letter->setStyleSheet("background-color:green");//to check if every word is added to the grid

        //qDebug()<<letter->text();

        occupiedCells.insert(QPoint(x, y));
    }
}

void minigame::addWordsToFind()
{
    //add the words to the grid vertical layout through a loop
    for (int i = 0;i<addWordsVector.size();i++)
    {
        words = new QLabel(this);
        words->setText(addWordsVector.at(i));
        words->setStyleSheet("color:rgb(0, 0, 0)");
        ui->verticalLayout->addWidget(words);
        //ui->verticalLayoutWidget->setAutoFillBackground(false);
    }
}

void minigame::isWordsFound()
{
    //static int count = 0;
    if (addWordsVector.contains(selectedLetters))
    {
        //qDebug() << "Word found: " << selectedLetters;
        if (foundWords.contains(selectedLetters))
        {
            //qDebug()<<foundWords.at(0);
            QMessageBox::information(this, "Word Already Found", "You have already found the word: " + selectedLetters);
            for (auto it = recentlySelectedButtons.begin(); it != recentlySelectedButtons.end(); ++it)
            {
                QPushButton *button = *it;
                // Reset the style of the button to default
                button->setStyleSheet("color:rgb(0, 0, 0);background-color:rgb(57,255,20);");
                greenButtons.insert(button);
            }
            selectedLetters.clear();
            recentlySelectedButtons.clear();
            return;
        }
        else
        {
            count++;
            //qDebug()<<count;
            foundWords.push_back(selectedLetters); // Mark this word as found

            // Iterate over each QLabel in the vertical layout
            for (int i = 0; i < ui->verticalLayout->count(); ++i)
            {
                QLabel *label = qobject_cast<QLabel*>(ui->verticalLayout->itemAt(i)->widget());

                if (label && label->text() == selectedLetters)
                {
                    label->setText(label->text() + " ✔️");
                    label->setStyleSheet("color:red;");
                    for (auto it = recentlySelectedButtons.begin(); it != recentlySelectedButtons.end(); ++it)
                    {
                        QPushButton *button = *it;
                        // Reset the style of the button to default
                        button->setStyleSheet("color:rgb(0, 0, 0);background-color:rgb(57,255,20);");
                        greenButtons.insert(button);
                    }
                    break; // Exit the loop once the word is found
                }
            }
        }
        //qDebug()<<"SelectedLetter:_"<<selectedLetters;
        selectedLetters.clear();
        recentlySelectedButtons.clear();
        score(count);
        stopTime(count);
    }
}


void minigame::changeButtonColor()
{
    QPushButton *buttonClicked = qobject_cast<QPushButton*>(sender());
    if (buttonClicked)
    {
        buttonClicked->setStyleSheet("color:rgb(0, 0, 0);background-color:orange;");
        // Add the clicked letter to the list of selected letters
        selectedLetters += buttonClicked->text();

        // Check if any word is formed by the selected letters
        //qDebug()<<"Selected Letters:"<<selectedLetters;

        // Add the clicked button to the set of recently selected buttons
        recentlySelectedButtons.insert(buttonClicked);

        //call the function to check if the word is found
        isWordsFound();
    }
}

void minigame::score(int count)
{
    int score;
    score = count * 5;
    //QString
    scoreText = QString::number(score);
    ui->scoreNum->setText(scoreText);
}

void minigame::on_remove_pushButton_clicked()
{
    {
        for (auto it = recentlySelectedButtons.begin(); it != recentlySelectedButtons.end(); ++it)
        {
            QPushButton *button = *it;
            // Reset the style of the button to default
            if (!greenButtons.contains(button))
            {
                button->setStyleSheet("color:rgb(0, 0, 0);background-color:rgb(255,255,255);");
            }
            if (greenButtons.contains(button))
            {
                button->setStyleSheet("color:rgb(0, 0, 0);background-color:rgb(57,255,20);");
            }
        }
    }
    selectedLetters.clear();
    recentlySelectedButtons.clear();
    //qDebug()<<"Selected Letters:"<<selectedLetters;
}

void minigame::stopTime(int count)
{
    if (count==addWordsVector.size())
    {
        times->stop();
        ui->gifLabel->setVisible(true);
        QMessageBox::information(this,"Congratulations","You have found all the words!");
        QMessageBox::information(this,"Thanks","Your score is: "+scoreText+". Thank you for playing!");
        times->stop();
       // ui->leaderBoard->setVisible(true);
        // ui->playAgainButton->setVisible(true);

        // Disable all buttons in the grid layout
        for (int i = 0; i < ui->gridLayout->count(); ++i)
        {
            QWidget *widget = ui->gridLayout->itemAt(i)->widget();
            if (QPushButton *button = qobject_cast<QPushButton *>(widget))
            {
                button->setEnabled(false);
            }
        }
        ui->done_pushButton_2->setEnabled(true);
    }
}

void minigame::on_done_pushButton_2_clicked()
{

    if (count != addWordsVector.size())
    {
        // Not all words found → ask confirmation
        QMessageBox::StandardButton reply;
        reply = QMessageBox::question(this,
                                      "Exit",
                                      "Are you sure? The timer will stop and word search will end.",
                                      QMessageBox::Yes | QMessageBox::No);

        if (reply != QMessageBox::Yes)
        {
            // User canceled, do nothing
            return;
        }
    }

    // Stop the timer
    times->stop();

    // Show appropriate message
    if (count == addWordsVector.size())
    {
        QMessageBox::information(this, "Congratulations",
                                 "You have found all the words! Thank you for playing!");
    }
    else
    {
        QMessageBox::information(this, "Score",
                                 "Your score is: " + scoreText + ". Thank you for playing!");
    }

    // Disable all buttons in the grid
    for (int i = 0; i < ui->gridLayout->count(); ++i)
    {
        QWidget *widget = ui->gridLayout->itemAt(i)->widget();
        if (QPushButton *button = qobject_cast<QPushButton *>(widget))
            button->setEnabled(false);
    }

    // Open levelSelect dialog
    levelSelect *levelDialog = new levelSelect();
    levelDialog->show();

    // Close/hide minigame
    this->close();
}




