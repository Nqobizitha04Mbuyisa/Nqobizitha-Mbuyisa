#ifndef MINIGAME_H
#define MINIGAME_H

#include "myfile.h"

#include <QMainWindow>
#include <QTimer>
#include <QVector>
#include <QString>
#include <QPushButton>
#include <QLabel>
#include <QSet>
#include <QPoint>
QT_BEGIN_NAMESPACE
namespace Ui {
class minigame;
}
QT_END_NAMESPACE

class minigame : public QMainWindow
{
    Q_OBJECT

public:
    minigame(QWidget *parent = nullptr);
    ~minigame();

protected:
    void resizeEvent(QResizeEvent *event) override;
    //void closeEvent(QCloseEvent *) override;

public slots:
    void populateWordSearch();
    void addWordsToFind();
    void startTimer();
    void isWordsFound();
    void changeButtonColor();
    void on_remove_pushButton_clicked();
    void on_done_pushButton_2_clicked();
    void score(int count);

    //private slots:
    //void on_playAgainButton_clicked();

private:
    Ui::minigame *ui;
    //void resizeEvent(QResizeEvent *event);
    QTimer *times;// = new QTimer(this);
    QString time_text;
    int count = 0;
    QVector<QString> addWordsVector= {"CELL", "DNA", "MITOSIS", "BIOLOGY", "CHROMOSOME", "ECOLOGY", "EUKARYOTE", "EVOLUTION", "GENE", "VIRUS"};
    //QPushButton *letter = new QPushButton(this);
    QVector<QString> foundWords;
    QString selectedLetters; // Store the selected letters
    QLabel *words = new QLabel(this);

    QSet<QPoint> occupiedCells; // Declare occupiedCells as a member variable

    // Define a set to store pointers to the recently selected buttons
    QSet<QPushButton*> recentlySelectedButtons;
    QSet<QPushButton*> greenButtons;

    QString scoreText;

    void placeWord(const QString &word, int startX, int startY, int directionX, int directionY);
    bool isWordPlacementPossible(const QString &word, int startX, int startY, int directionX, int directionY);
    void stopTime(int count);
};
#endif // minigame_h
