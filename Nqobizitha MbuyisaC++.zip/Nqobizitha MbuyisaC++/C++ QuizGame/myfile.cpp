#include "myfile.h"


myFile::myFile() {}

void myFile::setBackgroundImage(QWidget *widget, const QString &imagePath)
{
    QPixmap T(imagePath);
    T = T.scaled(widget ->size(),Qt::IgnoreAspectRatio);
    QPalette palette;
    palette.setBrush(QPalette::Window, T);
    widget->setPalette(palette);
}



