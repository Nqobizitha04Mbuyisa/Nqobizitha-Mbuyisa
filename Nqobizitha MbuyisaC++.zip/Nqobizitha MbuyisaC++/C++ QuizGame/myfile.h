#ifndef MYFILE_H
#define MYFILE_H


#include <QObject>
#include <QWidget>
#include <QPixmap>
#include <QPalette>


class myFile
{
public:
    myFile();
    void setBackgroundImage(QWidget *widget,const QString &imagePath);

};
#endif // MYFILE_H

