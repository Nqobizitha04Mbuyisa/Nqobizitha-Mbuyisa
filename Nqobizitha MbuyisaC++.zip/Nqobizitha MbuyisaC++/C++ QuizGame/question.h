#ifndef QUESTION_H
#define QUESTION_H

#include <QString>
#include <QVector>
#include <QPair>

struct Question {
    QString text;
    QString ans;
    QVector<QString> options;
    QString userAnswer; // Add this field
};

#endif // QUESTION_H
