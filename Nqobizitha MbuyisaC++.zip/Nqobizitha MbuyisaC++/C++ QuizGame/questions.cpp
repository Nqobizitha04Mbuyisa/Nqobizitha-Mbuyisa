#include "questions.h"
#include "ui_questions.h"
#include <QMessageBox>
#include <QXmlStreamReader>
#include <QFile>
#include <QDebug>

Questions::Questions(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Questions),
    m_currentQuestionIndex(0)
{
    ui->setupUi(this);
    m_quizWindow = new QuizWindow(this);
    setCentralWidget(m_quizWindow);

    loadQuestionsFromXml();
    displayNextQuestion();
}

Questions::~Questions()
{
    delete ui;
}

void Questions::loadQuestionsFromXml() {
    QFile file(":/questions.xml"); // Assume questions.xml is added as a resource
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Failed to open XML file";
        return;
    }

    QXmlStreamReader xml(&file);
    while (!xml.atEnd() && !xml.hasError()) {
        QXmlStreamReader::TokenType token = xml.readNext();
        if (token == QXmlStreamReader::StartElement && xml.name() == "question") {
            QString questionText;
            Question question("");

            while (!(xml.tokenType() == QXmlStreamReader::EndElement && xml.name() == "question")) {
                xml.readNext();
                if (xml.tokenType() == QXmlStreamReader::StartElement) {
                    if (xml.name() == "text") {
                        questionText = xml.readElementText();
                    } else if (xml.name() == "option") {
                        bool isCorrect = (xml.attributes().value("correct") == "true");
                        question.addOption(xml.readElementText(), isCorrect);
                    }
                }
            }

            question = Question(questionText);
            m_questions.append(question);
        }
    }

    if (xml.hasError()) {
        qDebug() << "XML Error: " << xml.errorString();
    }

    file.close();
}

void Questions::displayNextQuestion() {
    if (m_currentQuestionIndex < m_questions.size()) {
        m_quizWindow->setQuestion(m_questions[m_currentQuestionIndex]);
        m_currentQuestionIndex++;
    } else {
        // End of questions
        QMessageBox::information(this, "End of Quiz", "You've completed all questions!");
    }
}

void Questions::displayPreviousQuestion() {
    m_currentQuestionIndex -= 2;
    if (m_currentQuestionIndex >= 0) {
        m_quizWindow->setQuestion(m_questions[m_currentQuestionIndex]);
    } else {
        // Beginning of questions
        m_currentQuestionIndex = 0;
    }
}

void Questions::on_pushButton_clicked()
{
    displayNextQuestion();
}

void Questions::on_pushButton_2_clicked()
{
    displayPreviousQuestion();
}


