#ifndef QUESTIONS_H
#define QUESTIONS_H

#include <QMainWindow>

#include "quizwindow.h"

namespace Ui {
class Questions;
}

class Questions : public QMainWindow
{
    Q_OBJECT

public:
    explicit Questions(QWidget *parent = nullptr);
    ~Questions();

private slots:
    //QuizWindow *m_quizWindow;
    //QList<Question> m_questions;

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void loadQuestionsFromXml();
    void displayNextQuestion();
    void displayPreviousQuestion();


private:
    Ui::Questions *ui;
    int m_currentQuestionIndex;

};

#endif // QUESTIONS_H
