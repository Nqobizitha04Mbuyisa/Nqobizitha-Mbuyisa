#include "quiz.h"
#include "ui_quiz.h"
#include <QMessageBox>
#include <QDebug>
#include <QRandomGenerator>
#include <algorithm>
#include <QRandomGenerator>
#include <QTime>

#include "quizlvl2.h"
#include "levelselect.h"
#include "myfile.h"

Quiz::Quiz(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Quiz)
    , currentQuestionIndex(0)
    , score(0)
    , times(new QTimer(this)) // Initialize timer
    , timeRemaining(900) // Set initial time to 900 seconds (15 minutes)
{
    ui->setupUi(this);

    connect(ui->option1, &QRadioButton::clicked, this, [this](){
        checkAnswer(ui->option1);});
    connect(ui->option2, &QRadioButton::clicked, this, [this](){
        checkAnswer(ui->option2);});
    connect(ui->option3, &QRadioButton::clicked, this, [this](){
        checkAnswer(ui->option3);});
    connect(ui->option4, &QRadioButton::clicked, this, [this](){
        checkAnswer(ui->option4);});

    //displayQuestion(currentQuestionIndex);

    questions = parseXML(":/myFiles/Level1.xml");

    // Select 8 non-repeating random questions
    /*if (questions.size() > 8) {
        std::shuffle(questions.begin(), questions.end(), *QRandomGenerator::global());
        quizQuestions = questions.mid(0, 8);
    } else {
        quizQuestions = questions;
    }*/
    //displayQuestion(currentQuestionIndex);

    ui->correctImage->setVisible(false);
    ui->incorrectImg->setVisible(false);


    //timer declaration
    connect(times,&QTimer::timeout,this,&Quiz::startTimer);
    times->start(1000);
}

Quiz::~Quiz()
{
    delete ui;
}


void Quiz::displayQuestion(const int index)
{
    QString indexText = QString::number((index+1));
    ui->qNum->setText(indexText);
    if (index >= questions.size()) {
        return;
    }

    const Question& question = questions[index];
    qDebug()<<"DisplayQuestion "<<index;
    ui->questionss->setText(question.text);

    bool isTrueFalseQuestion = (question.options.size() == 2);

    ui->option1->setText(question.options.at(0));
    ui->option2->setText(question.options.at(1));
    ui->option1->setEnabled(true);
    ui->option2->setEnabled(true);

    ui->option3->setVisible(!isTrueFalseQuestion);
    ui->option4->setVisible(!isTrueFalseQuestion);
    ui->option3->setEnabled(!isTrueFalseQuestion);
    ui->option4->setEnabled(!isTrueFalseQuestion);

    if (!isTrueFalseQuestion) {
        ui->option3->setText(question.options.at(2));
        ui->option4->setText(question.options.at(3));
    }
}

void Quiz::on_pushButton_clicked()//next point
{

    ui->correctImage->setVisible(false);
    ui->incorrectImg->setVisible(false);

    ui->option1->setAutoExclusive(false);
    ui->option1->setChecked(false);
    ui->option1->setAutoExclusive(true);

    ui->option2->setAutoExclusive(false);
    ui->option2->setChecked(false);
    ui->option2->setAutoExclusive(true);

    ui->option3->setAutoExclusive(false);
    ui->option3->setChecked(false);
    ui->option3->setAutoExclusive(true);

    ui->option4->setAutoExclusive(false);
    ui->option4->setChecked(false);
    ui->option4->setAutoExclusive(true);
    //currentQuestionIndex = 0;
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.size()) {

        displayQuestion(currentQuestionIndex);
        //qDebug()<<"Index "<<currentQuestionIndex;
        //currentQuestionIndex++;
    } else {
        times->stop();
        this->hide();

        QString feedback;
        for (const Question& q : questions) {
            feedback += "Question: " + q.text + "\n";
            feedback += "Your Answer: " + q.userAnswer + "\n";
            feedback += "Correct Answer: " + q.ans + "\n\n";
        }

        QMessageBox::information(this, "Quiz Over", "Your total score is: " + QString::number(score)+ "\n\n" + feedback);

        levelSelect *levelNum = new levelSelect();
        levelNum->show();

        // QMessageBox msgBox;

        // msgBox.setWindowTitle("LEVEL 2 Upcoming");
        // msgBox.setText("Ready for Level 2?");
        // QPushButton *yesButton = msgBox.addButton(tr("Yes"), QMessageBox::AcceptRole);

        // msgBox.exec();

        // if (msgBox.clickedButton() == yesButton) {
        //     quizLvl2 *quiz2 = new quizLvl2;
        //     quiz2 -> displayQuestion(QRandomGenerator::global()->bounded(quiz2->questions.size()));
        //     quiz2->show();
        // }
    }
}
 void Quiz::checkAnswer(QRadioButton *btn)
 {
     QString selectedAnswer = btn->text();
     questions[currentQuestionIndex].userAnswer = selectedAnswer; // Store user's answer

     if(btn->text() == questions.at(currentQuestionIndex).ans){
        score++;
        ui->correctImage->setVisible(true);
     }
     else {
         ui->incorrectImg->setVisible(true);
     }

     // Disable all radio buttons after an answer is selected
     ui->option1->setEnabled(false);
     ui->option2->setEnabled(false);
     ui->option3->setEnabled(false);
     ui->option4->setEnabled(false);
 }



QVector<Question> Quiz::parseXML(const QString& filename)
{
    QVector<Question> questions;
    QFile file(filename);
    if (!file.open(QIODevice::ReadOnly)) {
        qDebug() << "Error opening XML file:" << file.errorString();
        return questions;
    }
    QXmlStreamReader xml(&file);
    while (!xml.atEnd() && !xml.hasError()) {
        if (xml.isStartElement() && xml.name() == QString("question")) {
            Question q;

            int currIndex=0;
            int corrIndex=0;

            while (!(xml.isEndElement() && xml.name() == QString("question"))) {
                if (xml.isStartElement() && xml.name() == QString("text")) {
                    q.text = xml.readElementText();
                }
                if (xml.isStartElement() && xml.name() == QString("option") &&
                    xml.attributes().value("correct").toString() == "true"){

                    corrIndex = currIndex;

                }
                if (xml.isStartElement() && xml.name() == QString("option")) {
                    QString optionText = xml.readElementText();
                    q.options.push_back(optionText);
                    currIndex++;
                }
                xml.readNext();
            }
            q.ans = q.options.at(corrIndex);
            questions.push_back(q);
        }
        xml.readNext();
    }

    file.close();


    /*qDebug() << "Parsed Questions:";
    for (const auto& q : questions) {
        qDebug() << q.text << q.options;
        //int count = 0;
    }*/
    if (questions.size() > 8) {
        std::shuffle(questions.begin(), questions.end(), *QRandomGenerator::global());
        questions = questions.mid(0, 8);
    }

    // qDebug() << "Selected Questions:";
    // for (const auto& q : questions) {
    //     qDebug() << q.text << q.options;
    // }

    return questions;
}

void Quiz::resizeEvent(QResizeEvent *event)
{
    QWidget::resizeEvent(event);
    myFile file;
    file.setBackgroundImage(this, ":/images/pexels-ekamelev-920157.jpg");
}

//set the timer for the level one
void Quiz::startTimer()
{
    //static int seconds=0;
    //seconds++;
    if (timeRemaining > 0) {
        timeRemaining--;

    // Create a QTime object with the remaining time
    QTime time(0, 0, 0);
    time = time.addSecs(timeRemaining);

        // Format the time as "HH : MM : SS"
    QString time_text = time.toString("hh : mm : ss");

    ui->timer->setText(time_text);

    if (timeRemaining == 0) {
        // Displays message box when time is up
        QMessageBox::warning(this, "Time", "Time is up!!!");
        times->stop();
        this->hide();

        QString feedback;
        for (const Question& q : questions) {
            feedback += "Question: " + q.text + "\n";
            feedback += "Your Answer: " + q.userAnswer + "\n";
            feedback += "Correct Answer: " + q.ans + "\n\n";
        }

        QMessageBox::information(this, "Quiz Over", "Your total score is: " + QString::number(score)+ "\n\n" + feedback);

        levelSelect *levelNum = new levelSelect();
        levelNum->show();
        }
    }
}


void Quiz::on_pushButton_2_clicked()
{
    levelSelect *levelNum = new levelSelect();
    levelNum->show();
    this->hide();
    times->stop();
}
