#ifndef QUIZ_H
#define QUIZ_H

#include <QMainWindow>
#include <QVector>
#include <QString>
#include <QPair>
#include <QFile>
#include <QXmlStreamReader>
#include <QTimer>

//#include "quizlevel2.h"
#include "question.h"
#include <QtXml>
#include <QRadioButton>

QT_BEGIN_NAMESPACE
namespace Ui {
class Quiz;
}

class Quiz : public QMainWindow
{
    Q_OBJECT

public:
    explicit Quiz(QWidget *parent = nullptr);
    ~Quiz();
    QVector<Question> parseXML(const QString& filename);

    void displayQuestion(const int index);
    QVector<Question> questions;
     QVector<int> questionIndex;
    //QSet<Question> parseXML(const QString& filename);
    //QSet<Question> questions;
    //QList<Question> quizQuestions;

     int currentQuestionIndex;

    //timer
    QTimer *times;// = new QTimer(this);
    QString time_text;
    void startTimer();
    int timeRemaining;

private slots:
    void on_pushButton_clicked();
    void checkAnswer(QRadioButton *btn);

    void on_pushButton_2_clicked();

private:
    Ui::Quiz *ui;
    void resizeEvent(QResizeEvent *event);
    int score;
};

#endif // QUIZ_H


