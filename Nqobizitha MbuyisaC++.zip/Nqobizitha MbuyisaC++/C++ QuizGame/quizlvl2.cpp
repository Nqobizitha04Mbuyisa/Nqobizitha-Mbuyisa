#include "quizlvl2.h"
#include "ui_quizlvl2.h"
#include <QMessageBox>
#include <QDebug>
#include <QRandomGenerator>
#include <algorithm>
#include <QTime>

#include "quizlvl3.h"
#include "levelselect.h"
#include "myfile.h"
quizLvl2::quizLvl2(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::quizLvl2)
    , currentQuestionIndex(0)
    , score(0)
    , times(new QTimer(this)) // Initialize timer
    , timeRemaining(600) // Set initial time to 600 seconds (10 minutes)
{
    ui->setupUi(this);

    ui->correctImage->setVisible(false);
    ui->correctImage_2->setVisible(false);

    connect(ui->rad1, &QRadioButton::clicked, this, [this](){
        checkAnswer(ui->rad1);});
    connect(ui->rad2, &QRadioButton::clicked, this, [this](){
        checkAnswer(ui->rad2);});
    connect(ui->rad3, &QRadioButton::clicked, this, [this](){
        checkAnswer(ui->rad3);});
    connect(ui->rad4, &QRadioButton::clicked, this, [this](){
        checkAnswer(ui->rad4);});

    displayQuestion(currentQuestionIndex);

    questions = parseXML(":/myFiles/Level2.xml");

    //timer declaration
    connect(times,&QTimer::timeout,this,&quizLvl2::startTimer);
    times->start(1000);
}

quizLvl2::~quizLvl2()
{
    delete ui;
}

void quizLvl2::displayQuestion(int index)
{

    QString indexText = QString::number((index+1));
    ui->qNum->setText(indexText);

    if (index >= questions.size()) {
        return;
    }

    if (index >= questions.size()) {
        return;
    }

    const Question& question = questions[index];
    ui->labelQ->setText(question.text);

    bool isTrueFalseQuestion = (question.options.size() == 2);

    ui->rad1->setText(question.options.at(0));
    ui->rad2->setText(question.options.at(1));
    ui->rad1->setEnabled(true);
    ui->rad2->setEnabled(true);

    ui->rad3->setVisible(!isTrueFalseQuestion);
    ui->rad4->setVisible(!isTrueFalseQuestion);
    ui->rad3->setEnabled(!isTrueFalseQuestion);
    ui->rad4->setEnabled(!isTrueFalseQuestion);

    if (!isTrueFalseQuestion) {
        ui->rad3->setText(question.options.at(2));
        ui->rad4->setText(question.options.at(3));
    }
}


void quizLvl2::on_next2_clicked()
{
    ui->correctImage->setVisible(false);
    ui->correctImage_2->setVisible(false);

    ui->rad1->setAutoExclusive(false);
    ui->rad1->setChecked(false);
    ui->rad1->setAutoExclusive(true);

    ui->rad2->setAutoExclusive(false);
    ui->rad2->setChecked(false);
    ui->rad2->setAutoExclusive(true);

    ui->rad3->setAutoExclusive(false);
    ui->rad3->setChecked(false);
    ui->rad3->setAutoExclusive(true);

    ui->rad4->setAutoExclusive(false);
    ui->rad4->setChecked(false);
    ui->rad4->setAutoExclusive(true);
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.size() ) {
        displayQuestion(currentQuestionIndex);
    } else {
        times->stop();
        this->hide();
        QString feedback;
        for (const Question& q : questions) {
            feedback += "Question: " + q.text + "\n";
            feedback += "Your Answer: " + q.userAnswer + "\n";
            feedback += "Correct Answer: " + q.ans + "\n\n";
        }

        QMessageBox::information(this, "Quiz Over",
                                 "Your total score is: " + QString::number(score) + "\n\n" + feedback);

        levelSelect *levelNum = new levelSelect();
        levelNum->show();
        // QMessageBox msgBox;
        // msgBox.setWindowTitle("LEVEL 3 Upcoming");
        // msgBox.setText("Ready for level 3?");
        // QPushButton *yesButton = msgBox.addButton(tr("Yes"), QMessageBox::AcceptRole);
        // msgBox.exec();
        // if (msgBox.clickedButton() == yesButton) {
        //     quizLvl3 *quiz2 = new quizLvl3;
        //     quiz2 -> displayQuestion(QRandomGenerator::global()->bounded(quiz2->questions.size()));
        //     quiz2->show();
        // }
    }
}


void quizLvl2::checkAnswer(QRadioButton *btn)
{
    QString selectedAnswer = btn->text();
    questions[currentQuestionIndex].userAnswer = selectedAnswer; // Store user's answer

    if (btn->text() == questions.at(currentQuestionIndex).ans) {
        score++;
        ui->correctImage->setVisible(true);
    }
    else {
        ui->correctImage_2->setVisible(true);
    }
    // Disable all radio buttons after an answer is selected
    ui->rad1->setEnabled(false);
    ui->rad2->setEnabled(false);
    ui->rad3->setEnabled(false);
    ui->rad4->setEnabled(false);
}

QVector<Question> quizLvl2::parseXML(const QString& filename)
{
    QVector<Question> questions;
    QFile file(filename);
    if (!file.open(QIODevice::ReadOnly)) {
        qDebug() << "Error opening XML file:" << file.errorString();
        return questions;
    }
    QXmlStreamReader xml(&file);
    while (!xml.atEnd() && !xml.hasError()) {
        if (xml.isStartElement() && xml.name() == QString("question")) {
            Question q;

            int currIndex = 0;
            int corrIndex = 0;

            while (!(xml.isEndElement() && xml.name() == QString("question"))) {
                if (xml.isStartElement() && xml.name() == QString("text")) {
                    q.text = xml.readElementText();
                }
                if (xml.isStartElement() && xml.name() == QString("option") &&
                    xml.attributes().value("correct").toString() == "true") {

                    corrIndex = currIndex;
                }
                if (xml.isStartElement() && xml.name() == QString("option")) {
                    QString optionText = xml.readElementText();
                    q.options.push_back(optionText);
                    currIndex++;
                }
                xml.readNext();
            }
            q.ans = q.options.at(corrIndex);
            questions.push_back(q);
        }
        xml.readNext();
    }
    file.close();

    if (questions.size() > 8) {
        std::shuffle(questions.begin(), questions.end(), *QRandomGenerator::global());
        questions = questions.mid(0, 8);
    }

    qDebug() << "Selected Questions:";
    for (const auto& q : questions) {
        qDebug() << q.text << q.options;
    }

    return questions;
}

void quizLvl2::resizeEvent(QResizeEvent *event)
{
    QWidget::resizeEvent(event);
    myFile file;
    file.setBackgroundImage(this, ":/images/pexels-ekamelev-920157.jpg");
}

//set the timer for the level
void quizLvl2::startTimer()
{
    //static int seconds=0;
    //seconds++;
    if (timeRemaining > 0) {
        timeRemaining--;

        // Create a QTime object with the remaining time
        QTime time(0, 0, 0);
        time = time.addSecs(timeRemaining);

        // Format the time as "HH : MM : SS"
        QString time_text = time.toString("hh : mm : ss");

        ui->timer->setText(time_text);

        if (timeRemaining == 0) {
            // Displays message box when time is up
            QMessageBox::warning(this, "Time", "Time is up!!!");
            times->stop();
            this->hide();

            QString feedback;
            for (const Question& q : questions) {
                feedback += "Question: " + q.text + "\n";
                feedback += "Your Answer: " + q.userAnswer + "\n";
                feedback += "Correct Answer: " + q.ans + "\n\n";
            }

            QMessageBox::information(this, "Quiz Over", "Your total score is: " + QString::number(score)+ "\n\n" + feedback);

            levelSelect *levelNum = new levelSelect();
            levelNum->show();

        }
    }
}



void quizLvl2::on_pushButton_2_clicked()
{
    levelSelect *levelNum = new levelSelect();
    levelNum->show();
    this->hide();
    times->stop();
}

