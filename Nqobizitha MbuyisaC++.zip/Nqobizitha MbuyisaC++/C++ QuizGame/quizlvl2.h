#ifndef QUIZLVL2_H
#define QUIZLVL2_H

#include <QMainWindow>
#include <QVector>
#include <QString>
#include <QPair>
#include <QFile>
#include <QXmlStreamReader>
#include "question.h"
#include <QtXml>
#include <QRadioButton>
#include <QTimer>


QT_BEGIN_NAMESPACE
namespace Ui {
class quizLvl2;
}

class quizLvl2 : public QMainWindow
{
    Q_OBJECT

public:
    explicit quizLvl2(QWidget *parent = nullptr);
    ~quizLvl2();
    QVector<Question> parseXML(const QString& filename);
    void displayQuestion(int index);
    QVector<Question> questions;

    QTimer *times;// = new QTimer(this);
    QString time_text;
    void startTimer();
    int timeRemaining;

    int currentQuestionIndex;

private slots:
    //void on_pushButton_clicked();
    void on_next2_clicked();
    void checkAnswer(QRadioButton *btn);

    void on_pushButton_2_clicked();

private:
    Ui::quizLvl2 *ui;
    void resizeEvent(QResizeEvent *event);
    int score;
};

#endif // QUIZLVL2_H
