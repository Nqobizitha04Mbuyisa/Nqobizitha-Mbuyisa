#include "startminigame.h"
#include "ui_startminigame.h"
#include "minigame.h"
#include "myfile.h"

#include <QFont>
#include <QTextEdit>
#include <QMessageBox>

#include "levelselect.h"
startminigame::startminigame(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::startminigame)
{
    ui->setupUi(this);
}

startminigame::~startminigame()
{
    delete ui;
}

void startminigame::resizeEvent(QResizeEvent *event)
{
    QWidget::resizeEvent(event);
    myFile file;

    file.setBackgroundImage(this,":/images/biology.jpg");
}

void startminigame::on_startMiniGameButton_clicked()
{
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this,"Exit","Are you sure you want to start the word search puzzle",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes)
    {
        minigame *miniGameStart = new minigame();
        miniGameStart->show();

        this->hide();
    }
}


void startminigame::on_pushButton_2_clicked()
{
    levelSelect *levelNum = new levelSelect();
    levelNum->show();
    this->hide();
}

