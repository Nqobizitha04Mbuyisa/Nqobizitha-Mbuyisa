#ifndef XMLFILES_H
#define XMLFILES_H

class xmlFiles
{
public:
    xmlFiles();
};

#endif // XMLFILES_H
